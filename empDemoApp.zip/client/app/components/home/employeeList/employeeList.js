import angular from 'angular';
import EmployeeListComponent from './employeeList.component';

let employeeListModule = angular.module('employeeList', [])

.component('employeeList', EmployeeListComponent)
  
.name;

export default employeeListModule;
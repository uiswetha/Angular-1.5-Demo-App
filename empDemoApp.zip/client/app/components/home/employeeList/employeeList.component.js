import template 		from './employeeList.html';
import controller 		from './employeeList.controller';

let employeeListComponent = {
	restrict: 'E',
	bindings:{
		isAddEmployeeVisible : '='
	},
	template,
	controller,
	controllerAs :'vm'
};

export default employeeListComponent;
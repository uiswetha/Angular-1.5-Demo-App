class EmployeeListController{
	constructor(EmployeeService){
		"ngInject";
		this.name = "employeeList";
		this.EmployeeService = EmployeeService;
		//Initialize empList to empty array.
		this.empList = [];

	}

	//Get List of employees on component load by calling EmployeeService
	$onInit(){
		this.empList = this.EmployeeService.getEmployeeList();
}


}

	export default EmployeeListController;
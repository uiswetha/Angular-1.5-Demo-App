class HomeController{
	constructor(){
		this.name = 'home';
		this.isAddEmployeeVisible = false;
		
	}

	//set variable on click of add Employee button to render add Employee component

	showAddEmployeeComponent(){

		this.isAddEmployeeVisible = true;
		
	}
}

export default HomeController;
class AddEmployeeController{
	constructor(EmployeeService){
		"ngInject";
		this.name ="addEmployee";
		this.EmployeeService = EmployeeService;
	}

 	resetForm(form){
		this.employee = {};
		//Reset form to pristine state to avoid unnecessary validations.
		form.$setPristine();
		this.isAddEmployeeVisible=false;
	}

	//Add new Employee by calling saveEmployee method in EmployeeService
	addNewEmployee(form){
		   
			this.EmployeeService.saveEmployee(this.employee);
			//Reset form values to null post save
			this.resetForm(form);
	}

	cancel(form){
		this.resetForm(form);
	}

	
}

	export default AddEmployeeController;
import angular from 'angular';
import AddEmployeeComponent from './addEmployee.component';

let addEmployeeModule = angular.module('addEmployee', [])

.component('addEmployee', AddEmployeeComponent)
  
.name;

export default addEmployeeModule;

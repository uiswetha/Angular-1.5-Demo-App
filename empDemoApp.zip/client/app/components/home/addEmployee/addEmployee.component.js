import template 		from './addEmployee.html';
import controller 		from './addEmployee.controller';

let addEmployeeComponent = {
	restrict: 'E',
	bindings:{
		isAddEmployeeVisible: '='
	},
	template,
	controller,
	controllerAs :'vm'
};

export default addEmployeeComponent;
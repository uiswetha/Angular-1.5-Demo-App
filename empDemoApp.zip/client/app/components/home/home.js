import angular 			from 'angular';
import uiRouter from 'angular-ui-router';
import HomeComponent 	from './home.component'

let homeModule = angular.module('home', [
	uiRouter])

.config(($stateProvider, $urlRouterProvider) => {
  "ngInject";

  $urlRouterProvider.otherwise('/home');

  $stateProvider
    .state('home', {
      url: '/home',
      component: 'home'
    });
})

.component('home', HomeComponent)

.name;

export default homeModule;
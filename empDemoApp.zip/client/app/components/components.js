import angular 		from 'angular';
import Home 		from './home/home';
import About		from './about/about';
import Navbar		from './navbar/navbar';
import AddEmployee   from './home/addEmployee/addEmployee'
import EmployeeList   from './home/employeeList/employeeList'

let componentModule = angular.module('components', [
	Home,
    About,
    Navbar,
    AddEmployee,
    EmployeeList


	])

   .name;

 export default componentModule;
function EmployeeService(){

	"ngInject";

   var employeeList=[{
			'fullName':'Mark',
			'department':'Systems Support',
			'designation':'Systems Engineer',
			'email':'mark@yahos.com',
			'phoneNumber':'77777777777'
		},
		{
			'fullName':'Charlie',
			'department':'Systems Support',
			'designation':'Systems Engineer',
			'email':'charlie@yahos.com',
			'phoneNumber':'77677777777'
		},
		{
			'fullName':'Dev',
			'department':'Web Development',
			'designation':'Sr. Web Developer',
			'email':'dev@yahos.com',
			'phoneNumber':'77777777778'
		},
		{
			'fullName':'Alley',
			'department':'Systems Support',
			'designation':'Systems Engineer',
			'email':'alley@yahos.com',
			'phoneNumber':'77777777779'
		},
		{
			'fullName':'Peter',
			'department':'Network Support',
			'designation':'Network Engineer',
			'email':'peter@yahos.com',
			'phoneNumber':'57777777777'
		},
		{
			'fullName':'Cherie',
			'department':'Security',
			'designation':'Security Engineer',
			'email':'cherie@yahos.com',
			'phoneNumber':'87777777777'
		
		}];
		return {
           getEmployeeList(){
	  			return employeeList;
           },

           saveEmployee(employee){
			  employeeList.push(employee);
			  console.log("employeeListCount:"+employeeList.length);
           }
}

}

export default EmployeeService;
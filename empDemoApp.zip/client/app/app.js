import angular           	from 'angular';
import uiRouter				from 'angular-ui-router';
import AppComponent			from './app.component';

import components			from './components/components';
import EmployeeService      from './services/EmployeeService'

angular.module('app',['ngMaterial', 'ngMessages',
	uiRouter,
	components
	])	

.config(($locationProvider) => {
	'ngInject';
	$locationProvider.html5Mode(true).hashPrefix('!');
	
})			
.component('app', AppComponent)
.factory('EmployeeService', EmployeeService);